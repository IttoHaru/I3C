﻿using System;

namespace _13C
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Zadej číslo a: ");
            double a = double.Parse(Console.ReadLine());

            Console.Write("Zadej číslo b: ");
            double b = double.Parse(Console.ReadLine());

            double c = a + b;

            Console.WriteLine("Součet čísel je " + c + ".");

            Console.WriteLine("------------");
            Console.WriteLine("a = " + a);
            Console.WriteLine("b = " + b);

            Console.WriteLine("a + b = " + c);
            Console.WriteLine("Součet čísel je " +  a + b);     //nezobrazí součet, ale za sebou ???
            Console.WriteLine("Součet čísel je " + (a + b));

            Console.WriteLine(a + " + " + b + "=" + c);

            double d = a - b;
            Console.WriteLine("Rozdíl čísel je " + d);
            //nebo
            Console.WriteLine("Rozdíl čísel je " + (a - b));

            Console.WriteLine("Součin čísel je " + a * b);
            Console.WriteLine("Podíl čísel je " + a / b);

            Console.Write("Zadej číslo e: ");
            int e = int.Parse(Console.ReadLine());

            Console.WriteLine("e % 2 = " + e % 2);

            Console.WriteLine(e + " % 5 = " + e % 5);

            Console.ReadLine();

        }
    }
}
