﻿using System;

namespace _07C
{
    class Program
    {
        static void Main(string[] args)
        {
            

            int a = 65;             //celá čísla
            float b = 0.2F;         //desetiná čísla
            double C = 3.2;         //desetiná čísla
            decimal d = 42.2M;      //peněžní hodnoty
            string e = "more";      //řetězec znaků - text
            char f = '<';           //1 znac z ASCII tabulky
            bool g = true;          //logická hodnota true and false444444444444444444444444444444444444444444444444444444444444444444444444444444444

            Console.WriteLine("hodnoty jsou");
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(C);
            Console.WriteLine(d);
            Console.WriteLine(e);
            Console.WriteLine(f);
            Console.WriteLine(g);

            Console.ReadLine();
        }
    }
}
