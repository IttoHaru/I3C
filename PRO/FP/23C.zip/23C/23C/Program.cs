﻿using System;

namespace _23C
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Výpočet obvodu čtverce");

            double a, o;
            Console.Write("hodnota 1: ");
            a = double.Parse(Console.ReadLine());

            if (a > 0)
            {
                o = 4 * a;
                Console.WriteLine("Obvod čtverce o straně " + a + " je " + o);
            }
            else
            {
                Console.WriteLine("Nelze");
            }

            Console.ReadLine();
        }
    }
}
