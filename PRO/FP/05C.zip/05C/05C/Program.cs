﻿using System;

namespace _05C
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("big eyed toe nail crap mutant"); //output on dysplay/console

            /*
            Console.WriteLine("big eyed toe nail crap mutant");
            */

            //Console.WriteLine("big eyed toe nail crap mutant");
            //Console.WriteLine("big eyed toe nail crap mutant");
            //Console.WriteLine("big eyed toe nail crap mutant");
        }
    }
}
