﻿using System;

namespace _24C
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("A / B = C");
            double a, b, c;

            Console.Write("hodnota A = ");
            a = double.Parse(Console.ReadLine());

            Console.Write("hodnota B = ");
            b = double.Parse(Console.ReadLine());

            if (b != 0) //lze také použít (b == 0)
            {
                c = a / b;
                Console.WriteLine("výsledek " + a + "/" + b + "=" + c);
            }
            else
            {
                Console.WriteLine("Nelze dělit nulou");
            }

            Console.ReadLine();
        }
    }
}
